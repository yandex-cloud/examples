import json
from typing import List, Union, Optional
from pathlib import Path
from collections import defaultdict


class ClusterReferences:
    def __init__(self):
        self._clusters = {}
        self._alias_to_centers = defaultdict(list)

    def add_cluster(self, center: str, aliases: List[str]) -> 'ClusterReferences':
        self._clusters[center] = aliases.copy()
        center = tuple(center.split())
        for alias in aliases:
            alias = tuple(alias.split())
            self._alias_to_centers[alias].append(center)
        return self

    def get(self, value, default_value):
        """
        Try to get a center value from cluster references,
        if it doesn't exists, returns default value
        """
        return self._alias_to_centers.get(value, default_value)

    def save(self, path: Union[str, Path]) -> None:
        Path(path).write_text(json.dumps(self._clusters, indent=2))

    def load(self, path: Union[str, Path]) -> 'ClusterReferences':
        clusters = json.loads(Path(path).read_text())
        self.__init__()
        for center, aliases in clusters.items():
            self.add_cluster(center, aliases)
        return self

    def __repr__(self):
        repr = ''
        for center, aliases in self._clusters.items():
            repr += '{} --> {}'.format(center, aliases) + '\n'
        return repr
