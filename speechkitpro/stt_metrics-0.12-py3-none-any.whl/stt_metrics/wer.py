import json
from typing import Dict, Optional, Tuple

from .resources import ClusterReferences
from .alignment_utils import visualize_raw_alignment, align_hypo_and_ref_for_words_wrapper
from .common import MetricData, Metric, evaluate_metric


class WERData(MetricData):
    errors_count: int
    hyp_words_count: int
    ref_words_count: int
    diff_hyp: str
    diff_ref: str

    def __init__(self,
                 errors_count: int,
                 hyp_words_count: int,
                 ref_words_count: int,
                 diff_hyp: str = '',
                 diff_ref: str = ''):
        self.errors_count = errors_count
        self.hyp_words_count = hyp_words_count
        self.ref_words_count = ref_words_count
        self.diff_hyp = diff_hyp
        self.diff_ref = diff_ref

    def __eq__(self, other: 'WERData'):
        return (
            self.errors_count == other.errors_count and
            self.hyp_words_count == other.hyp_words_count and
            self.ref_words_count == other.ref_words_count and
            self.diff_hyp == other.diff_hyp and
            self.diff_ref == other.diff_ref
        )

    def __repr__(self):
        return '{\n'                                 \
              f'  errors: {self.errors_count},\n'    \
              f'  hyp_wc: {self.hyp_words_count},\n' \
              f'  ref_wc: {self.ref_words_count},\n' \
              f'  diff_hyp: {self.diff_hyp},\n'      \
              f'  diff_ref: {self.diff_ref}\n'       \
               '}'

    def to_json(self) -> Dict:
        return {
            'errors': self.errors_count,
            'hyp_wc': self.hyp_words_count,
            'ref_wc': self.ref_words_count,
            'diff_hyp': self.diff_hyp,
            'diff_ref': self.diff_ref
        }

    @staticmethod
    def from_json(fields: Dict) -> 'WERData':
        return WERData(
            errors_count=fields['errors'],
            hyp_words_count=fields['hyp_wc'],
            ref_words_count=fields['ref_wc'],
            diff_hyp=fields['diff_hyp'],
            diff_ref=fields['diff_ref'],
        )


class WER(Metric):
    _cr: ClusterReferences

    def __init__(self, cr: ClusterReferences = None):
        super(WER, self).__init__(name='WER')
        if cr:
            self._cr = cr
        else:
            self._cr = ClusterReferences()

    def get_metric_data(self, hyp: str, ref: str) -> WERData:
        errors_count, hyp_words_count, ref_words_count, alignment = \
            align_hypo_and_ref_for_words_wrapper(hyp, ref, self._cr)
        diff_hyp, diff_ref = visualize_raw_alignment(alignment)
        return WERData(errors_count, hyp_words_count, ref_words_count, diff_hyp, diff_ref)

    @staticmethod
    def calculate_metric(metric_data: WERData) -> float:
        words_count = max(metric_data.hyp_words_count, metric_data.ref_words_count, 1)
        return min(metric_data.errors_count / words_count, 1.0)


def evaluate_wer(references: Dict[str, str],
                 hypotheses: Dict[str, str],
                 cluster_references: Optional[ClusterReferences] = None) -> Tuple[float, Dict[str, Dict]]:
    wer_calcer = WER(cr=cluster_references)
    return evaluate_metric(references, hypotheses, wer_calcer)
